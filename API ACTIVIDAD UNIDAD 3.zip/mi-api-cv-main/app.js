// API SIMPLE EXPERIENCIAS
const express = require('express');
const fs = require('fs');
const app = express();
app.use(express.json());

// Leer datos
const leerDatos = () => {
    try {
        return JSON.parse(fs.readFileSync('experiencias.json', 'utf8'));
    } catch {
        return [];
    }
};

// Guardar datos
const guardarDatos = (datos) => {
    fs.writeFileSync('experiencias.json', JSON.stringify(datos, null, 2));
};

// RUTAS
app.get('/', (req, res) => {
    res.json({ mensaje: 'API Funcionando!', status: 'OK' });
});

app.get('/api/experiencias', (req, res) => {
    res.json({ data: leerDatos() });
});

app.post('/api/experiencias', (req, res) => {
    const datos = leerDatos();
    const nuevo = {
        id: Date.now().toString(),
        ...req.body,
        fechaCreacion: new Date().toISOString()
    };
    datos.push(nuevo);
    guardarDatos(datos);
    res.json({ success: true, data: nuevo });
});

app.listen(5000, () => {
    console.log('✅ Servidor: http://localhost:5000');
});